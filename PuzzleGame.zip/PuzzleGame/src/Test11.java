import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Test11 extends JFrame implements ActionListener ,Runnable{

    JButton jButton;


    Test11(){
    }

    private void initJFrame() {
        this.setSize(400,300);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        this.setTitle("Test11");
        jButton = new JButton("Ckick me!");
        jButton.setBounds(0,0,100,50);
        this.setAlwaysOnTop(true);
        this.setLocationRelativeTo(null);
        this.getContentPane().add(jButton);
        jButton.addActionListener(this);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource() == jButton){
            Test12 test12 = new Test12();
            Thread t2 = new Thread(test12);
            t2.start();
            this.setVisible(false);
        }

    }

    @Override
    public void run() {
        initJFrame();
    }

}
