import java.util.Random;

public class Tester {
    public static void main(String args[]){
        Random random = new Random();

        int len = 0;
        char[] code = new char[5];

        while (len < 5){

            int x = random.nextInt(48,123);

            if((x >= 58 && x <= 64 ) || (x >= 91 && x <= 96))
                continue;
            else{
                code[len] = (char)x;
                len ++;
            }

        }

        String string = new String (code);
        System.out.println(string);

    }
}
