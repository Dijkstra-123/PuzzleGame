import java.awt.event.*;
import java.util.Random;
import javax.swing.*;
import javax.swing.border.BevelBorder;

public class JGameUI extends JFrame implements ActionListener,KeyListener{

    String type = "animal";
    int number = 3;
    String Path;

    int step = 0;

    int x;
    int y;
    int data[][] = new int[4][4];
    int win[][] = {
            {1,2,3,4},
            {5,6,7,8},
            {9,10,11,12},
            {13,14,15,0}
    };

    JMenu jMenu2 = new JMenu( "关于我们");
    JMenu jMenu11 = new JMenu("更换图片");

    JMenuItem jMenuItem2 = new JMenuItem("重新游戏");
    JMenuItem jMenuItem3 = new JMenuItem("重新登录");
    JMenuItem jMenuItem4 = new JMenuItem("关闭游戏");
    JMenuItem jMenuItem11 = new JMenuItem("美女");
    JMenuItem jMenuItem12 = new JMenuItem("动物");
    JMenuItem jMenuItem13 = new JMenuItem("运动");
    JMenuItem jMenuItem21 = new JMenuItem("QQ号");

    JGameUI() {


        initJFrame();

        initMenu();

        initData();

        initImage();

        this.setVisible(true);                //放在后面才能马上加载出来


    }

    private void initImgN0Check() {   //代码里面先出现的图片会被放在最上面~~~~~~~~~~~~~~~~~~~~~~~

        Path = "image\\" + type + "\\" + type + number + "\\";

        this.getContentPane().removeAll();   //清楚前面的就会在下面出现

        if(isWin()){
            ImageIcon win = new ImageIcon("image\\win.png");
            JLabel jwin = new JLabel(win);
            jwin.setBounds(245,290,197,73);
            this.getContentPane().add(jwin);
        }

        for(int i = 0;i < 4;i ++){
            for(int j = 0;j < 4;j ++){
                int num = data[i][j];
                JLabel jLabel = new JLabel(new ImageIcon(Path + num +".jpg"));
                jLabel.setBounds(133 + j * 105,119 + i * 105,105,105);
                jLabel.setBorder(new BevelBorder(BevelBorder.LOWERED));
                this.getContentPane().add(jLabel);
            }
        }

        JLabel jstep = new JLabel("步数为：" + step);
        jstep.setBounds(10,0,100,50);
        this.getContentPane().add(jstep);

        ImageIcon background1 = new ImageIcon("image\\background.png");
        JLabel background = new JLabel(background1);
        background.setBounds(90,25,508,560);
        this.getContentPane().add(background);

        this.getContentPane().repaint();  //刷新,不刷新加载出不来
    }

    private void initImage() {   //代码里面先出现的图片会被放在最上面~~~~~~~~~~~~~~~~~~~~~~~

        Path = "image\\" + type + "\\" + type + number + "\\";

        this.getContentPane().removeAll();   //清楚前面的就会在下面出现

        if(isWin()){
            ImageIcon win = new ImageIcon("image\\win.png");
            JLabel jwin = new JLabel(win);
            jwin.setBounds(245,290,197,73);
            this.getContentPane().add(jwin);
        }

        while(!capable()){
            initData();
        }

        for(int i = 0;i < 4;i ++){
            for(int j = 0;j < 4;j ++){
                int num = data[i][j];
                JLabel jLabel = new JLabel(new ImageIcon(Path + num +".jpg"));
                jLabel.setBounds(133 + j * 105,119 + i * 105,105,105);
                jLabel.setBorder(new BevelBorder(BevelBorder.LOWERED));
                this.getContentPane().add(jLabel);
            }
        }

        JLabel jstep = new JLabel("步数为：" + step);
        jstep.setBounds(10,0,100,50);
        this.getContentPane().add(jstep);

        ImageIcon background1 = new ImageIcon("image\\background.png");
        JLabel background = new JLabel(background1);
        background.setBounds(90,25,508,560);
        this.getContentPane().add(background);

        this.getContentPane().repaint();  //刷新,不刷新加载出不来
    }

    private void initData() {

        Random random = new Random();
        int temp;
        int TempArray[] = {1,0,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
        for(int i = 1;i <= TempArray.length;i ++){
            int a = random.nextInt(16);
            int b = random.nextInt(16);
            temp = TempArray[a];
            TempArray[a] = TempArray[b];
            TempArray[b] = temp;
        }

        for(int i = 0;i < 16;i ++){
            data[i/4][i%4] = TempArray[i];
            if(data[i/4][i%4] == 0){
                x = i/4;
                y = i%4;
            }
            System.out.print(data[i/4][i%4] + " ");
        }

    }

    private void initMenu() {
        JMenuBar jMenuBar1 = new JMenuBar();
        JMenu jMenu1 = new JMenu( "功能");

        jMenu11.add(jMenuItem11);
        jMenuItem11.addActionListener(this);
        jMenu11.add(jMenuItem12);
        jMenuItem12.addActionListener(this);
        jMenu11.add(jMenuItem13);
        jMenuItem13.addActionListener(this);
        jMenu1.add(jMenu11);
        jMenu1.add(jMenuItem2);
        jMenuItem2.addActionListener(this);
        jMenu1.add(jMenuItem3);
        jMenu1.add(jMenuItem4);
        jMenuItem4.addActionListener(this);
        jMenuBar1.add(jMenu1);                        //JMenu不能加ActionListener
        jMenu2.add(jMenuItem21);
        jMenuItem21.addActionListener(this);
        jMenuBar1.add(jMenu2);
        this.setJMenuBar(jMenuBar1);
    }

    private void initJFrame() {
        this.setSize(700,700);
        //this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setTitle("拼图游戏v1.0");
        this.setAlwaysOnTop(true);
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        addKeyListener(this);
    }

    private  boolean capable(){

        int num = 0;
        int len = 0;
        int[] array = new int[16];

        for (int i = 1;i <= 3;i ++){
            array[len] = data[0][i];
            len ++;
        }

        for (int i = 3;i >= 1;i --){
            array[len] = data[1][i];
            len ++;
        }

        for (int i = 1;i <= 3;i ++){
            array[len] = data[2][i];
            len ++;
        }

        for (int i = 3;i >= 0;i --){
            array[len] = data[3][i];
            len ++;
        }

        for (int i = 2;i >= 0;i --){
            array[len] = data[i][0];
            len ++;
        }

        // System.out.println("len" + len);

        //if(len == 16){
        for(int i = 1;i <= array.length - 1;i ++){
            if(array[i] == 0)
                continue;

            for (int j = 0;j < i;j ++){
                if(array[j] == 0)
                    continue;
                if(array[j] > array[i])
                    num ++;
            }

        }
        //}
       /* else
            System.out.println("False");*/

        if(num % 2 == 0)
            return true;
        else
            return false;

    }

    private boolean isWin(){
        for(int i = 0;i < data.length;i ++){
            for (int j = 0;j < data[i].length;j ++){
                if(data[i][j] != win[i][j])
                    return false;
            }
        }
        return true;
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    //上 38
    //下 40
    //左 37
    //右 39

    @Override
    public void keyPressed(KeyEvent e) {

        if(isWin())
            return;

        int a = e.getKeyCode();
        System.out.println(a);
        if(e.getKeyCode() == 38){

            if(x <= 0)
                return;

            data[x][y] = data[x - 1][y];
            data[x - 1][y] = 0;
            x --;

            step ++;
            initImgN0Check();

        } else if(e.getKeyCode() == 40){

            if(x >= 3)
                return;

            data[x][y] = data[x + 1][y];
            data[x + 1][y] = 0;
            x ++;

            step ++;
            initImgN0Check();

        }else if (e.getKeyCode() == 37){

            if(y <= 0)
                return;

            data[x][y] = data[x][y - 1];
            data[x][y - 1] = 0;
            y --;

            step ++;
            initImgN0Check();

        }else if(e.getKeyCode() == 39){

            if(y >= 3)
                return;

            data[x][y] = data[x][y + 1];
            data[x][y + 1] = 0;
            y ++;

            step ++;
            initImgN0Check();

        }else if(e.getKeyCode() == 65){

            this.getContentPane().removeAll();

            ImageIcon imageIcon = new ImageIcon("image\\" + type + "\\" + type + number + "\\all.jpg");
            JLabel jLabel = new JLabel(imageIcon);
            jLabel.setBounds(134,120,420,420);
            this.getContentPane().add(jLabel);

            JLabel jstep = new JLabel("步数为：" + step);
            jstep.setBounds(10,0,100,50);
            this.getContentPane().add(jstep);

            ImageIcon background1 = new ImageIcon("image\\background.png");
            JLabel background = new JLabel(background1);
            background.setBounds(90,25,508,560);
            this.getContentPane().add(background);

            this.getContentPane().repaint();

        } else if (e.getKeyCode() == 87) {
            for(int i = 0;i < data.length;i ++){
                for (int j = 0;j < data[i].length;j ++){
                    data[i][j] = win[i][j];
                }
            }
            initImgN0Check();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        System.out.println(e.getKeyCode());
        if(e.getKeyCode() == 65){
            initImgN0Check();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == jMenuItem2){

            initData();
            step = 0;
            initImage();

        } else if (e.getSource() == jMenuItem4) {

            System.exit(0);

        } else if (e.getSource() == jMenuItem21) {

            JDialog dialog = new JDialog();
            dialog.setSize(900,900);
            dialog.setTitle("About us");
            dialog.setAlwaysOnTop(true);
            dialog.setLocationRelativeTo(null);
            ImageIcon imageIcon = new ImageIcon("image\\qq.jpg");
            JLabel jLabel = new JLabel(imageIcon);
            jLabel.setBounds(0,0,806,801);
            dialog.getContentPane().add(jLabel);
            dialog.setModal(true);
            dialog.setVisible(true);

        } else if (e.getSource() == jMenuItem11) {

            if(isWin())
                return;

            Random random = new Random();
            type = "girl";
            number = random.nextInt(13) + 1;

            step = 0;
            initImage();

        } else if (e.getSource() == jMenuItem12) {

            if(isWin())
                return;

            Random random = new Random();
            type = "animal";
            number = random.nextInt(8) + 1;

            step = 0;
            initImage();

        }else if (e.getSource() == jMenuItem13) {

            if(isWin())
                return;

            Random random = new Random();
            type = "sport";
            number = random.nextInt(10) + 1;

            step = 0;
            initImage();

        }
    }


}
