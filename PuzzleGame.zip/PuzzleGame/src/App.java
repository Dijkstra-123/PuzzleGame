import java.util.ArrayList;

public class App {

    public static ArrayList<User> Information = new ArrayList<>();

    static {
            Information.add(new User("zhangsan","123"));
            Information.add(new User("lisi","1234"));
    }

    public static void main(String args[]){

        new JLoginUI();

    }
}
