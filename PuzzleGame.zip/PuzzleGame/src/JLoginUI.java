import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class JLoginUI extends JFrame implements MouseListener{

    JLabel jcode = new JLabel("Initial Text");    //下面本来右new 但是init方法化了，没new直接接入了
                                                    //要不是通义千问我就完蛋了~~~~~~~~~~~~
    JButton jLoginButton;
    JButton jRegisterButton;
    JButton jCanseeButton;
    JPasswordField jPasswordField;
    JTextField jAccountNumber;

    JTextField jCodeNumber;

    JLoginUI (){
        initJFrame();

        initView();

        //最后
        this.setVisible(true);
    }

    private void initView() {
        //用户账号输入
        ImageIcon imgAccount = new ImageIcon("image\\login\\用户名.png");
        JLabel jAccount = new JLabel(imgAccount);
        jAccount.setBounds(108,150,47,17);
        this.getContentPane().add(jAccount);
        jAccountNumber = new JTextField(10);
        jAccountNumber.setBounds(158,148,200,29);
        this.getContentPane().add(jAccountNumber);

        //用户账号密码输入
        ImageIcon imgKey = new ImageIcon("image\\login\\密码.png");
        JLabel jKey= new JLabel(imgKey);
        jKey.setBounds(120,198,32,16);
        this.getContentPane().add(jKey);
        jPasswordField = new JPasswordField(10);
        jPasswordField.setBounds(158,198,200,29);
        this.getContentPane().add(jPasswordField);
        ImageIcon ImgCansee = new ImageIcon("image\\login\\显示密码.png");
        jCanseeButton = new JButton(ImgCansee);
        jCanseeButton.setContentAreaFilled(false);
        jCanseeButton.setBorderPainted(false);
        jCanseeButton.setBounds(358,198,18,29);
        jCanseeButton.addMouseListener(this);
        this.getContentPane().add(jCanseeButton);

        //验证码输入
        ImageIcon imgCode = new ImageIcon("image\\login\\验证码.png");
        JLabel jCode = new JLabel(imgCode);
        jCode.setBounds(108,250,47,17);
        this.getContentPane().add(jCode);
        jCodeNumber = new JTextField(5);
        jCodeNumber.setBounds(158,248,100,29);
        this.getContentPane().add(jCodeNumber);

        //验证码
        initCode();
        jcode.setBounds(278,248,100,29);
        jcode.addMouseListener(this);
        this.getContentPane().add(jcode);

        //登录按钮
        ImageIcon ImgLoginButton = new ImageIcon("image\\login\\登录按钮.png");
        jLoginButton = new JButton(ImgLoginButton);
        jLoginButton.setBounds(115,309,128,47);
        jLoginButton.setBorderPainted(false);
        jLoginButton.setContentAreaFilled(false);
        jLoginButton.addMouseListener(this);
        this.getContentPane().add(jLoginButton);

        //注册按钮
        ImageIcon imgRegister = new ImageIcon("image\\login\\注册按钮.png");
        jRegisterButton = new JButton(imgRegister);
        jRegisterButton.setBounds(259,309,128,47);
        jRegisterButton.setContentAreaFilled(false);
        jRegisterButton.setBorderPainted(false);
        jRegisterButton.addMouseListener(this);
        this.getContentPane().add(jRegisterButton);

        ImageIcon imgBackground = new ImageIcon("image\\login\\background.png");
        JLabel  jBackground = new JLabel(imgBackground);
        jBackground.setBounds(0,0,470,390);
        this.getContentPane().add(jBackground);

        //this.getContentPane().repaint();
    }

    private void initCode() {
        String string = new EnsureCode().getRandomCode();
        jcode.setText(string);
    }

    private void initJFrame() {
        this.setSize(485,420);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setAlwaysOnTop(true);
        this.setLocationRelativeTo(null);
        this.setLayout(null);
        this.setTitle("登录");
    }


    @Override
    public void mouseClicked(MouseEvent e) {

        if(e.getSource() == jcode){
            initCode();
        }

    }


    @Override
    public void mousePressed(MouseEvent e) {

        if(e.getSource() == jLoginButton){
            ImageIcon ImgAftLogin = new ImageIcon("image\\login\\登录按下.png");
            jLoginButton.setIcon(ImgAftLogin);
        }else if(e.getSource() == jRegisterButton){
            ImageIcon ImgAftRegister = new ImageIcon("image\\login\\注册按下.png");
            jRegisterButton.setIcon(ImgAftRegister);
        }else if (e.getSource() == jCanseeButton) {
            ImageIcon ImgAftCansee = new ImageIcon("image\\login\\显示密码按下.png");
            jCanseeButton.setIcon(ImgAftCansee);
            jPasswordField.setEchoChar((char) 0);
        }

    }

    @Override
    public void mouseReleased(MouseEvent e) {

        //登录按钮按下之后
        if(e.getSource() == jLoginButton){
            //按钮恢复
            ImageIcon ImgLogin = new ImageIcon("image\\login\\登录按钮.png");
            jLoginButton.setIcon(ImgLogin);

            //检查验证码输入是否正确
            if(jcode.getText().isEmpty()){

                showMessage("请输入验证码！");

            }
            else if(!(jcode.getText().equals(jCodeNumber.getText()))){

                showMessage("验证码数入错误！");
                initCode();

            } else if (jAccountNumber.getText().isEmpty() && String.valueOf(jPasswordField.getPassword()).isEmpty()) {

                showMessage("用户名和密码不能同时为空！");

            } else if (jAccountNumber.getText().isEmpty()) {

                showMessage("用户名不能为空！");

            } else if (String.valueOf(jPasswordField.getPassword()).isEmpty()) {

                showMessage("密码不能为空！");

            } else if (jcode.getText().equals(jCodeNumber.getText())){

                System.out.println( "jAccountNumber :  "+ jAccountNumber.getText());
                System.out.println( "jPasswordField :  "+ String.valueOf(jPasswordField.getPassword()));
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

                boolean flag = true;

                for (User user : App.Information) {

                    System.out.println( "Information 's Account :  "+ user.getAccount());
                    System.out.println( "Information 's Key :  "+ user.getKey());
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

                    boolean passWordblanket = user.getKey().equals(String.valueOf(jPasswordField.getPassword()));
                    boolean accountblancket = user.getAccount().equals(jAccountNumber.getText());

                    if (accountblancket && passWordblanket) {
                        flag = true;
                        break;
                    }
                    else {
                        flag = false;
                    }

                }

                if(flag){

                    this.setVisible(false);
                    new JGameUI();

                }
                else {
                    showMessage("账户或者密码输入错误");
                    jAccountNumber.setText(null);
                    jPasswordField.setText(null);
                }

            }
        }else if(e.getSource() == jRegisterButton){
            ImageIcon ImgRegister = new ImageIcon("image\\login\\注册按钮.png");
            jRegisterButton.setIcon(ImgRegister);

            this.setVisible(false);
            //创建注册界面
            new JRegisterUI();

        } else if (e.getSource() == jCanseeButton) {
            ImageIcon ImgCansee = new ImageIcon("image\\login\\显示密码.png");
            jCanseeButton.setIcon(ImgCansee);
            jPasswordField.setEchoChar('*');
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    public static void showMessage(String content){
        JDialog jDialog = new JDialog();
        jDialog.setSize(400,300);
        jDialog.setTitle("Warining!!!");
        jDialog.setModal(true);
        jDialog.setAlwaysOnTop(true);
        jDialog.setLocationRelativeTo(null);
        JLabel Warining = new JLabel(content);
        jDialog.add(Warining);
        //end
        jDialog.setVisible(true);
    }

}

class EnsureCode{

    EnsureCode(){

    }

    String getRandomCode(){

        Random random = new Random();

        int len = 0;

        char[] code = new char[5];

        while (len < 5){

            int x = random.nextInt(48,123);

            if((x >= 58 && x <= 64 ) || (x >= 91 && x <= 96))
                continue;
            else{
                code[len] = (char)x;
                len ++;
            }

        }

        String string = new String(code);

        return string;
    }


}
