import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

public class JRegisterUI extends JFrame implements MouseListener,KeyListener{

    JTextField jAccountNumber;
    JPasswordField jPasswordField;
    JButton jRegisterButton;
    JTextField jPasswordField2;
    JButton jResetButton;

    JRegisterUI (){

        initJFrame();

        initView();

        //最后
        this.setVisible(true);
    }

    private void initView() {
        //注册用户名
        ImageIcon imgAccount = new ImageIcon("image\\register\\注册用户名.png");
        JLabel jAccount = new JLabel(imgAccount);
        jAccount.setBounds(79,150,79,17);
        this.getContentPane().add(jAccount);
        jAccountNumber = new JTextField(10);
        jAccountNumber.setBounds(158,148,200,29);
        this.getContentPane().add(jAccountNumber);

        //用户账号密码
        ImageIcon imgKey = new ImageIcon("image\\register\\注册密码.png");
        JLabel jKey= new JLabel(imgKey);
        jKey.setBounds(89,198,64,16);
        this.getContentPane().add(jKey);
        jPasswordField = new JPasswordField(10);
        jPasswordField.setBounds(158,198,200,29);
        this.getContentPane().add(jPasswordField);

        //再次输入
        ImageIcon imgReKey = new ImageIcon("image\\register\\再次输入密码.png");
        JLabel jReKey = new JLabel(imgReKey);
        jReKey.setBounds(60,250,96,17);
        this.getContentPane().add(jReKey);
        jPasswordField2 = new JTextField(10);
        jPasswordField2.setBounds(158,248,200,29);
        this.getContentPane().add(jPasswordField2);

        //注册
        ImageIcon ImgRegister = new ImageIcon("image\\register\\注册按钮.png");
        jRegisterButton = new JButton(ImgRegister);
        jRegisterButton.setBounds(120,309,128,47);
        jRegisterButton.setBorderPainted(false);
        jRegisterButton.setContentAreaFilled(false);
        jRegisterButton.addMouseListener(this);
        this.getContentPane().add(jRegisterButton);

        //注册按钮
        ImageIcon ImgReset = new ImageIcon("image\\register\\重置按钮.png");
        jResetButton = new JButton(ImgReset);
        jResetButton.setBounds(259,309,128,47);
        jResetButton.setContentAreaFilled(false);
        jResetButton.setBorderPainted(false);
        jResetButton.addMouseListener(this);
        this.getContentPane().add(jResetButton);

        ImageIcon imgBackground = new ImageIcon("image\\register\\background.png");
        JLabel  jBackground = new JLabel(imgBackground);
        jBackground.setBounds(0,0,470,390);
        this.getContentPane().add(jBackground);

        //this.getContentPane().repaint();
    }

    private void initJFrame() {
        this.setSize(485,420);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setAlwaysOnTop(true);
        this.setLocationRelativeTo(null);
        this.setTitle("注册");
    }


    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

        if(e.getSource() == jRegisterButton){
            ImageIcon ImgAftRegister = new ImageIcon("image\\register\\注册按下.png");
            jRegisterButton.setIcon(ImgAftRegister);
        }else if(e.getSource() == jResetButton){
            ImageIcon ImgAftReset = new ImageIcon("image\\register\\重置按下.png");
            jResetButton.setIcon(ImgAftReset);
        }

    }

    @Override
    public void mouseReleased(MouseEvent e) {

        //注册按钮按下之后
        if(e.getSource() == jRegisterButton){
            ImageIcon ImgLogin = new ImageIcon("image\\register\\注册按钮.png");
            jRegisterButton.setIcon(ImgLogin);

            if(jAccountNumber.getText().isEmpty()){
                JLoginUI.showMessage("用户名不能为空！");
            } else if(String.valueOf(jPasswordField.getPassword()) == null){
                JLoginUI.showMessage("密码不能为空！");
            }else if(String.valueOf(jPasswordField.getPassword()) != null && jPasswordField2.getText().isEmpty()){
                JLoginUI.showMessage("请再次输入密码！");
            }else {
                App.Information.add(new User(jAccountNumber.getText(),String.valueOf(jPasswordField.getPassword())));
                this.setVisible(false);
                new JLoginUI();
            }
        }else if(e.getSource() == jResetButton){
            ImageIcon ImgRegister = new ImageIcon("image\\register\\重置按钮.png");
            jResetButton.setIcon(ImgRegister);

            if(!(String.valueOf(jPasswordField.getPassword()) == null)){
                jAccountNumber.setText(null);
            }
            if(!jPasswordField.getText().isEmpty()){
                jPasswordField.setText(null);
            }
            if(!jPasswordField2.getText().isEmpty()){
                jPasswordField2.setText(null);
            }
        }

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void keyTyped(KeyEvent e) {
        String Blank = jPasswordField.getPassword().toString();
    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}

