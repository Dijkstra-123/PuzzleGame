import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Test12 extends JFrame implements ActionListener,Runnable{

        JButton jButton;


        Test12(){
        }

    private void initJFrame() {
        this.setSize(400,300);
        this.setDefaultCloseOperation(HIDE_ON_CLOSE);
        this.setTitle("Test12");
        jButton = new JButton("Ckick me!");
        jButton.setBounds(0,0,100,50);
        this.setAlwaysOnTop(true);
        this.setLocationRelativeTo(null);
        this.getContentPane().add(jButton);
        jButton.addActionListener(this);
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

            if(e.getSource() == jButton)
                System.out.println("HAHAHAHAHAHAHA!");

    }


    @Override
    public void run() {
          initJFrame();

    }

}
