public class Test1 {



    public static void main(String args[]){
        Test11 test11 = new Test11();
        Thread t = new Thread(test11);
        t.start();
    }

}
