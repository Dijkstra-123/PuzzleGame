import javax.swing.*;
import java.awt.*;

public class JButtonTest {
    public static void main(String args[]){
        new WindowTest();
    }
}

class WindowTest extends JFrame {

    JButton jButton = new JButton();
    WindowTest(){
      this.setSize(400,300);
      this.setDefaultCloseOperation(EXIT_ON_CLOSE);
      this.setTitle("Mine");
      ImageIcon jicon = new ImageIcon("image\\login\\显示密码.png");
      jButton.setIcon(jicon);
      this.getContentPane().add(jButton);
      this.setVisible(true);
    }

}
