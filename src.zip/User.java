public class User {

    User(String Account, String key){
        this.Account = Account;
        this.key = key;
    }
    private String Account;
    private String key;

    public String getAccount() {
        return Account;
    }

    public String getKey() {
        return key;
    }

}
